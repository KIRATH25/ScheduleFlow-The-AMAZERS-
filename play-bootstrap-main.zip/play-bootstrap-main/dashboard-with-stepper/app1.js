// Timetable Setup Wizard Application
class TimetableWizard {
    constructor() {
        this.currentStep = 1;
        this.totalSteps = 7;
        this.stepCompletion = {
            1: false, 2: false, 3: false, 4: false, 5: false, 6: false, 7: false
        };
        
        // Application data storage
        this.data = {
            generalSettings: {
                institutionName: '',
                academicYear: '',
                timetableName: '',
                workingDays: [],
                periodsPerDay: 6,
                periodDuration: 45,
                breakDuration: 15,
                startTime: '09:00',
                endTime: ''
            },
            subjects: [],
            teachers: [],
            classes: [],
            rooms: [],
            timetable: null
        };

        // Sample data for dropdowns
        this.sampleData = {
            workingDays: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'],
            categories: ['Core', 'Elective', 'Special'],
            departments: ['Mathematics', 'Science', 'English', 'Social Studies', 'Arts', 'Physical Education', 'Technology'],
            gradeLevels: ['Pre-K', 'Kindergarten', 'Grade 1', 'Grade 2', 'Grade 3', 'Grade 4', 'Grade 5', 'Grade 6', 'Grade 7', 'Grade 8', 'Grade 9', 'Grade 10', 'Grade 11', 'Grade 12'],
            roomTypes: ['Classroom', 'Laboratory', 'Auditorium', 'Gymnasium', 'Library', 'Computer Lab', 'Art Studio', 'Music Room'],
            equipment: ['Projector', 'Whiteboard', 'Smart Board', 'Computer', 'Audio System', 'Laboratory Equipment', 'Sports Equipment', 'Art Supplies'],
            sections: ['A', 'B', 'C', 'D', 'E', 'F']
        };

        this.init();
    }

    init() {
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', () => {
                this.setup();
            });
        } else {
            this.setup();
        }
    }

    setup() {
        this.populateFormOptions();
        this.bindEvents();
        this.updateUI();
        this.calculateEndTime();
        console.log('TimetableWizard initialized successfully');
    }

    populateFormOptions() {
        // Populate working days
        this.populateWorkingDays();
        
        // Populate periods per day dropdown
        this.populatePeriodsPerDay();
        
        // Set up form change listeners for real-time validation
        this.setupFormValidation();
    }

    populateWorkingDays() {
        const workingDaysContainer = document.getElementById('working-days');
        if (workingDaysContainer) {
            workingDaysContainer.innerHTML = '';
            this.sampleData.workingDays.forEach(day => {
                const checkboxItem = document.createElement('div');
                checkboxItem.className = 'checkbox-item';
                checkboxItem.setAttribute('tabindex', '0');
                checkboxItem.setAttribute('role', 'checkbox');
                checkboxItem.setAttribute('aria-checked', 'false');
                
                const checkbox = document.createElement('input');
                checkbox.type = 'checkbox';
                checkbox.id = `day-${day.toLowerCase()}`;
                checkbox.name = 'workingDays';
                checkbox.value = day;
                checkbox.setAttribute('tabindex', '-1');
                
                const label = document.createElement('label');
                label.htmlFor = `day-${day.toLowerCase()}`;
                label.textContent = day.substring(0, 3);
                
                checkboxItem.appendChild(checkbox);
                checkboxItem.appendChild(label);
                workingDaysContainer.appendChild(checkboxItem);

                // Handle checkbox interactions
                const toggleCheckbox = () => {
                    checkbox.checked = !checkbox.checked;
                    this.updateCheckboxUI(checkboxItem, checkbox.checked);
                    this.updateWorkingDays();
                    this.calculateEndTime();
                    this.validateCurrentStep();
                };

                checkboxItem.addEventListener('click', (e) => {
                    e.preventDefault();
                    toggleCheckbox();
                });

                checkboxItem.addEventListener('keydown', (e) => {
                    if (e.key === 'Enter' || e.key === ' ') {
                        e.preventDefault();
                        toggleCheckbox();
                    }
                });

                checkbox.addEventListener('change', () => {
                    this.updateCheckboxUI(checkboxItem, checkbox.checked);
                    this.updateWorkingDays();
                    this.calculateEndTime();
                    this.validateCurrentStep();
                });

                // Default to weekdays
                if (!['Saturday', 'Sunday'].includes(day)) {
                    checkbox.checked = true;
                    this.updateCheckboxUI(checkboxItem, true);
                }
            });
            this.updateWorkingDays();
        }
    }

    populatePeriodsPerDay() {
        const periodsSelect = document.getElementById('periods-per-day');
        if (periodsSelect) {
            for (let i = 1; i <= 12; i++) {
                const option = document.createElement('option');
                option.value = i;
                option.textContent = `${i} period${i > 1 ? 's' : ''}`;
                periodsSelect.appendChild(option);
            }
            periodsSelect.value = '6'; // Default value
        }
    }

    updateCheckboxUI(checkboxItem, checked) {
        if (checked) {
            checkboxItem.classList.add('checked');
            checkboxItem.setAttribute('aria-checked', 'true');
        } else {
            checkboxItem.classList.remove('checked');
            checkboxItem.setAttribute('aria-checked', 'false');
        }
    }

    updateWorkingDays() {
        const checkboxes = document.querySelectorAll('input[name="workingDays"]:checked');
        this.data.generalSettings.workingDays = Array.from(checkboxes).map(cb => cb.value);
    }

    calculateEndTime() {
        const startTime = document.getElementById('start-time')?.value;
        const periodsPerDay = parseInt(document.getElementById('periods-per-day')?.value) || 6;
        const periodDuration = parseInt(document.getElementById('period-duration')?.value) || 45;
        const breakDuration = parseInt(document.getElementById('break-duration')?.value) || 15;
        const endTimeField = document.getElementById('end-time');

        if (startTime && endTimeField) {
            const [hours, minutes] = startTime.split(':').map(Number);
            const startMinutes = hours * 60 + minutes;
            
            // Calculate total duration: periods + breaks between periods
            const totalDuration = (periodsPerDay * periodDuration) + ((periodsPerDay - 1) * breakDuration);
            const endMinutes = startMinutes + totalDuration;
            
            const endHours = Math.floor(endMinutes / 60);
            const endMins = endMinutes % 60;
            
            const formattedEndTime = `${endHours.toString().padStart(2, '0')}:${endMins.toString().padStart(2, '0')}`;
            endTimeField.value = formattedEndTime;
            this.data.generalSettings.endTime = formattedEndTime;
        }
    }

    setupFormValidation() {
        // Add event listeners for form inputs
        const form = document.getElementById('general-settings-form');
        if (form) {
            const inputs = form.querySelectorAll('input, select');
            inputs.forEach(input => {
                input.addEventListener('input', () => {
                    this.validateField(input);
                    this.calculateEndTime();
                    this.validateCurrentStep();
                });
                input.addEventListener('change', () => {
                    this.validateField(input);
                    this.calculateEndTime();
                    this.validateCurrentStep();
                });
            });
        }
    }

    validateField(field) {
        const fieldName = field.name;
        const value = field.value.trim();
        let isValid = true;
        let errorMessage = '';

        // Remove existing error state
        field.classList.remove('error');
        const existingError = field.parentNode.querySelector('.error-message');
        if (existingError) {
            existingError.remove();
        }

        // Validation rules
        switch (fieldName) {
            case 'institutionName':
                if (!value || value.length < 2) {
                    isValid = false;
                    errorMessage = 'Institution name must be at least 2 characters long';
                }
                break;
            case 'academicYear':
                const yearPattern = /^\d{4}-\d{4}$/;
                if (!value || !yearPattern.test(value)) {
                    isValid = false;
                    errorMessage = 'Please enter academic year in format YYYY-YYYY (e.g., 2024-2025)';
                }
                break;
            case 'timetableName':
                if (!value || value.length < 3) {
                    isValid = false;
                    errorMessage = 'Timetable name must be at least 3 characters long';
                }
                break;
            case 'periodsPerDay':
                const periods = parseInt(value);
                if (!value || periods < 1 || periods > 12) {
                    isValid = false;
                    errorMessage = 'Please select number of periods per day (1-12)';
                }
                break;
            case 'periodDuration':
                const duration = parseInt(value);
                if (!value || duration < 30 || duration > 90) {
                    isValid = false;
                    errorMessage = 'Please select period duration (30-90 minutes)';
                }
                break;
            case 'startTime':
                if (!value) {
                    isValid = false;
                    errorMessage = 'Please select start time';
                }
                break;
        }

        if (!isValid) {
            field.classList.add('error');
            field.parentNode.classList.add('has-error');
            
            const errorDiv = document.createElement('div');
            errorDiv.className = 'error-message';
            errorDiv.textContent = errorMessage;
            field.parentNode.appendChild(errorDiv);
        } else {
            field.parentNode.classList.remove('has-error');
        }

        return isValid;
    }

    bindEvents() {
        // Step navigation events
        this.bindStepNavigation();
        
        // Navigation footer events
        this.bindFooterNavigation();
        
        // Modal events
        this.bindModalEvents();
        
        // Action button events
        this.bindActionButtons();

        // Window events
        window.addEventListener('resize', () => {
            this.handleResponsiveLayout();
        });

        // Keyboard shortcuts
        document.addEventListener('keydown', (e) => {
            this.handleKeyboardShortcuts(e);
        });
    }

    bindStepNavigation() {
        const stepTabs = document.querySelectorAll('.step-tab');
        stepTabs.forEach(tab => {
            tab.addEventListener('click', (e) => {
                e.preventDefault();
                const targetStep = parseInt(tab.getAttribute('data-step'));
                
                if (!tab.classList.contains('disabled')) {
                    this.navigateToStep(targetStep);
                }
            });
        });
    }

    bindFooterNavigation() {
        const prevBtn = document.getElementById('prev-btn');
        const nextBtn = document.getElementById('next-btn');

        if (prevBtn) {
            prevBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.navigatePrevious();
            });
        }

        if (nextBtn) {
            nextBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.navigateNext();
            });
        }
    }

    bindModalEvents() {
        const modal = document.getElementById('add-edit-modal');
        const modalClose = document.getElementById('modal-close');
        const modalCancel = document.getElementById('modal-cancel');
        const modalForm = document.getElementById('modal-form');

        if (modalClose) {
            modalClose.addEventListener('click', () => {
                this.hideModal();
            });
        }

        if (modalCancel) {
            modalCancel.addEventListener('click', () => {
                this.hideModal();
            });
        }

        if (modal) {
            modal.addEventListener('click', (e) => {
                if (e.target === modal || e.target.classList.contains('modal-overlay')) {
                    this.hideModal();
                }
            });
        }

        if (modalForm) {
            modalForm.addEventListener('submit', (e) => {
                this.handleModalSubmit(e);
            });
        }

        // Success modal events
        const successModal = document.getElementById('success-modal');
        const successClose = document.getElementById('success-modal-close');
        const successOk = document.getElementById('success-ok');

        if (successClose) {
            successClose.addEventListener('click', () => {
                this.hideSuccessModal();
            });
        }

        if (successOk) {
            successOk.addEventListener('click', () => {
                this.hideSuccessModal();
            });
        }
    }

    bindActionButtons() {
        // Add buttons for each step
        const addSubjectBtn = document.getElementById('add-subject-btn');
        const addTeacherBtn = document.getElementById('add-teacher-btn');
        const addClassBtn = document.getElementById('add-class-btn');
        const addRoomBtn = document.getElementById('add-room-btn');
        const generateTimetableBtn = document.getElementById('generate-timetable-btn');

        if (addSubjectBtn) {
            addSubjectBtn.addEventListener('click', () => this.showAddSubjectModal());
        }

        if (addTeacherBtn) {
            addTeacherBtn.addEventListener('click', () => this.showAddTeacherModal());
        }

        if (addClassBtn) {
            addClassBtn.addEventListener('click', () => this.showAddClassModal());
        }

        if (addRoomBtn) {
            addRoomBtn.addEventListener('click', () => this.showAddRoomModal());
        }

        if (generateTimetableBtn) {
            generateTimetableBtn.addEventListener('click', () => this.generateTimetable());
        }

        // Export buttons
        const exportPdfBtn = document.getElementById('export-pdf-btn');
        const exportExcelBtn = document.getElementById('export-excel-btn');
        const saveProjectBtn = document.getElementById('save-project-btn');

        if (exportPdfBtn) {
            exportPdfBtn.addEventListener('click', () => this.exportToPDF());
        }

        if (exportExcelBtn) {
            exportExcelBtn.addEventListener('click', () => this.exportToExcel());
        }

        if (saveProjectBtn) {
            saveProjectBtn.addEventListener('click', () => this.saveProject());
        }
    }

    handleKeyboardShortcuts(e) {
        if (e.key === 'Escape') {
            this.hideModal();
            this.hideSuccessModal();
        }

        if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
            e.preventDefault();
            this.navigateNext();
        }
    }

    navigateToStep(stepNumber) {
        if (stepNumber < 1 || stepNumber > this.totalSteps) return;
        
        // Check if we can navigate to this step
        if (stepNumber > this.currentStep + 1) {
            // Can't skip steps ahead
            this.showNotification('Please complete the current step before proceeding.', 'warning');
            return;
        }

        // Hide current step
        const currentStepElement = document.getElementById(`step-${this.currentStep}`);
        if (currentStepElement) {
            currentStepElement.classList.remove('active');
        }

        // Update current step
        this.currentStep = stepNumber;

        // Show new step
        const newStepElement = document.getElementById(`step-${this.currentStep}`);
        if (newStepElement) {
            newStepElement.classList.add('active');
        }

        // Update UI
        this.updateUI();
        this.updateStepData();
    }

    navigateNext() {
        if (this.currentStep >= this.totalSteps) return;

        // Validate current step before proceeding
        if (!this.validateCurrentStep()) {
            this.showNotification('Please complete all required fields in the current step.', 'error');
            return;
        }

        // Mark current step as completed
        this.stepCompletion[this.currentStep] = true;
        
        // Navigate to next step
        this.navigateToStep(this.currentStep + 1);
        this.showNotification(`Step ${this.currentStep} completed successfully!`, 'success');
    }

    navigatePrevious() {
        if (this.currentStep <= 1) return;
        this.navigateToStep(this.currentStep - 1);
    }

    validateCurrentStep() {
        switch (this.currentStep) {
            case 1:
                return this.validateGeneralSettings();
            case 2:
                return this.validateSubjects();
            case 3:
                return this.validateTeachers();
            case 4:
                return this.validateClasses();
            case 5:
                return this.validateRooms();
            case 6:
                return this.validateTimetableGeneration();
            case 7:
                return true; // Review step is always valid
            default:
                return false;
        }
    }

    validateGeneralSettings() {
        const form = document.getElementById('general-settings-form');
        if (!form) return false;

        const requiredFields = ['institutionName', 'academicYear', 'timetableName', 'periodsPerDay', 'periodDuration', 'startTime'];
        let isValid = true;

        // Validate required fields
        for (const fieldName of requiredFields) {
            const field = form.querySelector(`[name="${fieldName}"]`);
            if (field && !this.validateField(field)) {
                isValid = false;
            }
        }

        // Validate working days (at least 5 required)
        if (this.data.generalSettings.workingDays.length < 5) {
            isValid = false;
            this.showNotification('Please select at least 5 working days.', 'error');
        }

        // Store valid data
        if (isValid) {
            const formData = new FormData(form);
            this.data.generalSettings.institutionName = formData.get('institutionName');
            this.data.generalSettings.academicYear = formData.get('academicYear');
            this.data.generalSettings.timetableName = formData.get('timetableName');
            this.data.generalSettings.periodsPerDay = parseInt(formData.get('periodsPerDay'));
            this.data.generalSettings.periodDuration = parseInt(formData.get('periodDuration'));
            this.data.generalSettings.breakDuration = parseInt(formData.get('breakDuration'));
            this.data.generalSettings.startTime = formData.get('startTime');
        }

        return isValid;
    }

    validateSubjects() {
        return this.data.subjects.length >= 3;
    }

    validateTeachers() {
        return this.data.teachers.length >= 2;
    }

    validateClasses() {
        return this.data.classes.length >= 2;
    }

    validateRooms() {
        return this.data.rooms.length >= 3;
    }

    validateTimetableGeneration() {
        return this.data.timetable !== null;
    }

    updateUI() {
        this.updateStepTabs();
        this.updateNavigationButtons();
        this.updateStepIndicator();
        this.updateTableViews();
        this.updateGenerationSummary();
        this.updateReviewSummary();
    }

    updateStepTabs() {
        const stepTabs = document.querySelectorAll('.step-tab');
        stepTabs.forEach((tab, index) => {
            const stepNumber = index + 1;
            tab.classList.remove('active', 'completed', 'disabled');

            if (stepNumber === this.currentStep) {
                tab.classList.add('active');
            } else if (this.stepCompletion[stepNumber]) {
                tab.classList.add('completed');
            } else if (stepNumber > this.currentStep) {
                // Can only access next step if current is completed
                if (!this.stepCompletion[this.currentStep]) {
                    tab.classList.add('disabled');
                }
            }
        });
    }

    updateNavigationButtons() {
        const prevBtn = document.getElementById('prev-btn');
        const nextBtn = document.getElementById('next-btn');

        if (prevBtn) {
            prevBtn.disabled = this.currentStep <= 1;
        }

        if (nextBtn) {
            if (this.currentStep >= this.totalSteps) {
                nextBtn.style.display = 'none';
            } else {
                nextBtn.style.display = 'flex';
                nextBtn.disabled = false;
            }
        }
    }

    updateStepIndicator() {
        const currentStepNumber = document.getElementById('current-step-number');
        const navStepText = document.getElementById('nav-step-text');

        if (currentStepNumber) {
            currentStepNumber.textContent = this.currentStep;
        }

        if (navStepText) {
            const stepNames = [
                'General Settings',
                'Subjects/Courses',
                'Teachers/Instructors', 
                'Classes/Grades',
                'Rooms',
                'Timetable Generation',
                'Review & Export'
            ];
            navStepText.textContent = `Step ${this.currentStep}: ${stepNames[this.currentStep - 1]}`;
        }
    }

    updateStepData() {
        // Update step-specific data displays
        switch (this.currentStep) {
            case 2:
                this.updateSubjectsTable();
                break;
            case 3:
                this.updateTeachersTable();
                break;
            case 4:
                this.updateClassesTable();
                break;
            case 5:
                this.updateRoomsTable();
                break;
            case 6:
                this.updateGenerationSummary();
                break;
            case 7:
                this.updateReviewSummary();
                break;
        }
    }

    updateTableViews() {
        this.updateSubjectsTable();
        this.updateTeachersTable();
        this.updateClassesTable();
        this.updateRoomsTable();
    }

    updateSubjectsTable() {
        const tbody = document.getElementById('subjects-tbody');
        const emptyState = document.getElementById('subjects-empty');
        const tableContainer = document.querySelector('#step-2 .table-container');

        if (!tbody || !emptyState || !tableContainer) return;

        if (this.data.subjects.length === 0) {
            tableContainer.style.display = 'none';
            emptyState.style.display = 'block';
        } else {
            tableContainer.style.display = 'block';
            emptyState.style.display = 'none';

            tbody.innerHTML = '';
            this.data.subjects.forEach((subject, index) => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${this.escapeHtml(subject.name)}</td>
                    <td>${this.escapeHtml(subject.code)}</td>
                    <td><span class="status status--info">${this.escapeHtml(subject.category)}</span></td>
                    <td>${subject.creditHours}</td>
                    <td>
                        <div class="table-actions">
                            <button class="action-btn" onclick="app.editSubject(${index})" title="Edit Subject">
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/>
                                    <path d="m18.5 2.5 3 3L12 15l-4 1 1-4 9.5-9.5z"/>
                                </svg>
                            </button>
                            <button class="action-btn action-btn--danger" onclick="app.deleteSubject(${index})" title="Delete Subject">
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <polyline points="3,6 5,6 21,6"/>
                                    <path d="m19,6v14a2,2 0 0,1 -2,2H7a2,2 0 0,1 -2,-2V6m3,0V4a2,2 0 0,1 2,-2h4a2,2 0 0,1 2,2v2"/>
                                </svg>
                            </button>
                        </div>
                    </td>
                `;
                tbody.appendChild(row);
            });
        }
    }

    updateTeachersTable() {
        const tbody = document.getElementById('teachers-tbody');
        const emptyState = document.getElementById('teachers-empty');
        const tableContainer = document.querySelector('#step-3 .table-container');

        if (!tbody || !emptyState || !tableContainer) return;

        if (this.data.teachers.length === 0) {
            tableContainer.style.display = 'none';
            emptyState.style.display = 'block';
        } else {
            tableContainer.style.display = 'block';
            emptyState.style.display = 'none';

            tbody.innerHTML = '';
            this.data.teachers.forEach((teacher, index) => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${this.escapeHtml(teacher.fullName)}</td>
                    <td>${this.escapeHtml(teacher.employeeId)}</td>
                    <td><span class="status status--success">${teacher.subjectsTeaching.join(', ')}</span></td>
                    <td>${teacher.maxHoursPerWeek} hrs/week</td>
                    <td>
                        <div class="table-actions">
                            <button class="action-btn" onclick="app.editTeacher(${index})" title="Edit Teacher">
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/>
                                    <path d="m18.5 2.5 3 3L12 15l-4 1 1-4 9.5-9.5z"/>
                                </svg>
                            </button>
                            <button class="action-btn action-btn--danger" onclick="app.deleteTeacher(${index})" title="Delete Teacher">
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <polyline points="3,6 5,6 21,6"/>
                                    <path d="m19,6v14a2,2 0 0,1 -2,2H7a2,2 0 0,1 -2,-2V6m3,0V4a2,2 0 0,1 2,-2h4a2,2 0 0,1 2,2v2"/>
                                </svg>
                            </button>
                        </div>
                    </td>
                `;
                tbody.appendChild(row);
            });
        }
    }

    updateClassesTable() {
        const tbody = document.getElementById('classes-tbody');
        const emptyState = document.getElementById('classes-empty');
        const tableContainer = document.querySelector('#step-4 .table-container');

        if (!tbody || !emptyState || !tableContainer) return;

        if (this.data.classes.length === 0) {
            tableContainer.style.display = 'none';
            emptyState.style.display = 'block';
        } else {
            tableContainer.style.display = 'block';
            emptyState.style.display = 'none';

            tbody.innerHTML = '';
            this.data.classes.forEach((cls, index) => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${this.escapeHtml(cls.className)}</td>
                    <td><span class="status status--info">${this.escapeHtml(cls.gradeLevel)}</span></td>
                    <td>${cls.classTeacher ? this.escapeHtml(cls.classTeacher.name) : 'Not assigned'}</td>
                    <td>${cls.studentCount} students</td>
                    <td>
                        <div class="table-actions">
                            <button class="action-btn" onclick="app.editClass(${index})" title="Edit Class">
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/>
                                    <path d="m18.5 2.5 3 3L12 15l-4 1 1-4 9.5-9.5z"/>
                                </svg>
                            </button>
                            <button class="action-btn action-btn--danger" onclick="app.deleteClass(${index})" title="Delete Class">
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <polyline points="3,6 5,6 21,6"/>
                                    <path d="m19,6v14a2,2 0 0,1 -2,2H7a2,2 0 0,1 -2,-2V6m3,0V4a2,2 0 0,1 2,-2h4a2,2 0 0,1 2,2v2"/>
                                </svg>
                            </button>
                        </div>
                    </td>
                `;
                tbody.appendChild(row);
            });
        }
    }

    updateRoomsTable() {
        const tbody = document.getElementById('rooms-tbody');
        const emptyState = document.getElementById('rooms-empty');
        const tableContainer = document.querySelector('#step-5 .table-container');

        if (!tbody || !emptyState || !tableContainer) return;

        if (this.data.rooms.length === 0) {
            tableContainer.style.display = 'none';
            emptyState.style.display = 'block';
        } else {
            tableContainer.style.display = 'block';
            emptyState.style.display = 'none';

            tbody.innerHTML = '';
            this.data.rooms.forEach((room, index) => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${this.escapeHtml(room.roomName)}</td>
                    <td><span class="status status--info">${this.escapeHtml(room.roomType)}</span></td>
                    <td>${room.capacity} seats</td>
                    <td><span class="status status--success">${room.equipment.join(', ')}</span></td>
                    <td>
                        <div class="table-actions">
                            <button class="action-btn" onclick="app.editRoom(${index})" title="Edit Room">
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/>
                                    <path d="m18.5 2.5 3 3L12 15l-4 1 1-4 9.5-9.5z"/>
                                </svg>
                            </button>
                            <button class="action-btn action-btn--danger" onclick="app.deleteRoom(${index})" title="Delete Room">
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <polyline points="3,6 5,6 21,6"/>
                                    <path d="m19,6v14a2,2 0 0,1 -2,2H7a2,2 0 0,1 -2,-2V6m3,0V4a2,2 0 0,1 2,-2h4a2,2 0 0,1 2,2v2"/>
                                </svg>
                            </button>
                        </div>
                    </td>
                `;
                tbody.appendChild(row);
            });
        }
    }

    updateGenerationSummary() {
        const summaryContainer = document.getElementById('generation-summary');
        if (!summaryContainer) return;

        const summary = `
            <h3>Setup Summary</h3>
            <div class="summary-grid">
                <div class="summary-item">
                    <strong>Institution:</strong> ${this.data.generalSettings.institutionName || 'Not set'}
                </div>
                <div class="summary-item">
                    <strong>Academic Year:</strong> ${this.data.generalSettings.academicYear || 'Not set'}
                </div>
                <div class="summary-item">
                    <strong>Subjects:</strong> ${this.data.subjects.length} added
                </div>
                <div class="summary-item">
                    <strong>Teachers:</strong> ${this.data.teachers.length} added
                </div>
                <div class="summary-item">
                    <strong>Classes:</strong> ${this.data.classes.length} added
                </div>
                <div class="summary-item">
                    <strong>Rooms:</strong> ${this.data.rooms.length} added
                </div>
                <div class="summary-item">
                    <strong>Working Days:</strong> ${this.data.generalSettings.workingDays.length} days
                </div>
                <div class="summary-item">
                    <strong>Periods per Day:</strong> ${this.data.generalSettings.periodsPerDay}
                </div>
            </div>
        `;

        summaryContainer.innerHTML = summary;
    }

    updateReviewSummary() {
        const summaryContainer = document.getElementById('review-summary');
        if (!summaryContainer) return;

        const completionStatus = Object.values(this.stepCompletion).filter(Boolean).length;
        const summary = `
            <h3>Final Review</h3>
            <div class="review-stats">
                <div class="stat-item">
                    <h4>${completionStatus}/${this.totalSteps}</h4>
                    <p>Steps Completed</p>
                </div>
                <div class="stat-item">
                    <h4>${this.data.subjects.length + this.data.teachers.length + this.data.classes.length + this.data.rooms.length}</h4>
                    <p>Total Items Added</p>
                </div>
                <div class="stat-item">
                    <h4>${this.data.timetable ? 'Generated' : 'Not Generated'}</h4>
                    <p>Timetable Status</p>
                </div>
            </div>
            <div class="completion-checklist">
                <h4>Completion Checklist:</h4>
                <ul>
                    <li class="${this.stepCompletion[1] ? 'completed' : 'pending'}">
                        ✓ General Settings Configured
                    </li>
                    <li class="${this.stepCompletion[2] ? 'completed' : 'pending'}">
                        ✓ ${this.data.subjects.length} Subjects Added
                    </li>
                    <li class="${this.stepCompletion[3] ? 'completed' : 'pending'}">
                        ✓ ${this.data.teachers.length} Teachers Added
                    </li>
                    <li class="${this.stepCompletion[4] ? 'completed' : 'pending'}">
                        ✓ ${this.data.classes.length} Classes Added
                    </li>
                    <li class="${this.stepCompletion[5] ? 'completed' : 'pending'}">
                        ✓ ${this.data.rooms.length} Rooms Added
                    </li>
                    <li class="${this.stepCompletion[6] ? 'completed' : 'pending'}">
                        ✓ Timetable Generated
                    </li>
                </ul>
            </div>
        `;

        summaryContainer.innerHTML = summary;
    }

    // Modal functions
    showAddSubjectModal() {
        this.showModal('Add Subject', this.getSubjectFormHTML());
    }

    showAddTeacherModal() {
        this.showModal('Add Teacher', this.getTeacherFormHTML());
    }

    showAddClassModal() {
        this.showModal('Add Class', this.getClassFormHTML());
    }

    showAddRoomModal() {
        this.showModal('Add Room', this.getRoomFormHTML());
    }

    getSubjectFormHTML() {
        return `
            <div class="form-row">
                <div class="form-group">
                    <label class="form-label" for="subject-name">Subject Name *</label>
                    <input type="text" class="form-control" id="subject-name" name="subjectName" required>
                </div>
                <div class="form-group">
                    <label class="form-label" for="subject-code">Subject Code *</label>
                    <input type="text" class="form-control" id="subject-code" name="subjectCode" required>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label class="form-label" for="subject-category">Category *</label>
                    <select class="form-control" id="subject-category" name="category" required>
                        <option value="">Select category</option>
                        ${this.sampleData.categories.map(cat => `<option value="${cat}">${cat}</option>`).join('')}
                    </select>
                </div>
                <div class="form-group">
                    <label class="form-label" for="credit-hours">Credit Hours *</label>
                    <select class="form-control" id="credit-hours" name="creditHours" required>
                        <option value="">Select hours</option>
                        ${[1,2,3,4,5,6].map(h => `<option value="${h}">${h} hour${h > 1 ? 's' : ''}</option>`).join('')}
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label class="form-label" for="subject-description">Description</label>
                <textarea class="form-control" id="subject-description" name="description" rows="3"></textarea>
            </div>
        `;
    }

    getTeacherFormHTML() {
        return `
            <div class="form-row">
                <div class="form-group">
                    <label class="form-label" for="teacher-name">Full Name *</label>
                    <input type="text" class="form-control" id="teacher-name" name="fullName" required>
                </div>
                <div class="form-group">
                    <label class="form-label" for="employee-id">Employee ID *</label>
                    <input type="text" class="form-control" id="employee-id" name="employeeId" required>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label class="form-label" for="teacher-email">Email Address *</label>
                    <input type="email" class="form-control" id="teacher-email" name="email" required>
                </div>
                <div class="form-group">
                    <label class="form-label" for="max-hours">Max Hours per Week *</label>
                    <input type="number" class="form-control" id="max-hours" name="maxHoursPerWeek" min="1" max="40" required>
                </div>
            </div>
            <div class="form-group">
                <label class="form-label">Subjects Teaching *</label>
                <div class="multi-select" id="subjects-teaching">
                    ${this.data.subjects.map(subject => `
                        <label class="checkbox-item">
                            <input type="checkbox" name="subjectsTeaching" value="${subject.name}">
                            <span>${subject.name}</span>
                        </label>
                    `).join('')}
                </div>
            </div>
        `;
    }

    getClassFormHTML() {
        return `
            <div class="form-row">
                <div class="form-group">
                    <label class="form-label" for="class-name">Class Name *</label>
                    <input type="text" class="form-control" id="class-name" name="className" required>
                </div>
                <div class="form-group">
                    <label class="form-label" for="grade-level">Grade Level *</label>
                    <select class="form-control" id="grade-level" name="gradeLevel" required>
                        <option value="">Select grade</option>
                        ${this.sampleData.gradeLevels.map(grade => `<option value="${grade}">${grade}</option>`).join('')}
                    </select>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label class="form-label" for="class-teacher">Class Teacher</label>
                    <select class="form-control" id="class-teacher" name="classTeacher">
                        <option value="">Select teacher</option>
                        ${this.data.teachers.map((teacher, index) => `<option value="${index}">${teacher.fullName}</option>`).join('')}
                    </select>
                </div>
                <div class="form-group">
                    <label class="form-label" for="student-count">Student Count *</label>
                    <input type="number" class="form-control" id="student-count" name="studentCount" min="1" max="60" required>
                </div>
            </div>
        `;
    }

    getRoomFormHTML() {
        return `
            <div class="form-row">
                <div class="form-group">
                    <label class="form-label" for="room-name">Room Name *</label>
                    <input type="text" class="form-control" id="room-name" name="roomName" required>
                </div>
                <div class="form-group">
                    <label class="form-label" for="room-type">Room Type *</label>
                    <select class="form-control" id="room-type" name="roomType" required>
                        <option value="">Select type</option>
                        ${this.sampleData.roomTypes.map(type => `<option value="${type}">${type}</option>`).join('')}
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label class="form-label" for="room-capacity">Capacity *</label>
                <input type="number" class="form-control" id="room-capacity" name="capacity" min="1" max="200" required>
            </div>
            <div class="form-group">
                <label class="form-label">Equipment Available</label>
                <div class="multi-select" id="room-equipment">
                    ${this.sampleData.equipment.map(equip => `
                        <label class="checkbox-item">
                            <input type="checkbox" name="equipment" value="${equip}">
                            <span>${equip}</span>
                        </label>
                    `).join('')}
                </div>
            </div>
        `;
    }

    showModal(title, content, submitText = 'Add') {
        const modal = document.getElementById('add-edit-modal');
        const modalTitle = document.getElementById('modal-title');
        const modalContent = document.getElementById('modal-form-content');
        const submitButton = document.getElementById('modal-submit');

        if (modalTitle) modalTitle.textContent = title;
        if (modalContent) modalContent.innerHTML = content;
        if (submitButton) submitButton.textContent = submitText;

        if (modal) {
            modal.classList.remove('hidden');
            document.body.style.overflow = 'hidden';
        }
    }

    hideModal() {
        const modal = document.getElementById('add-edit-modal');
        if (modal) {
            modal.classList.add('hidden');
            document.body.style.overflow = '';
        }
        
        // Reset form
        const form = document.getElementById('modal-form');
        if (form) {
            form.reset();
        }
    }

    handleModalSubmit(e) {
        e.preventDefault();
        
        const form = e.target;
        const formData = new FormData(form);
        const submitButton = document.getElementById('modal-submit');
        
        // Add loading state
        if (submitButton) {
            submitButton.classList.add('btn--loading');
            submitButton.disabled = true;
        }

        // Simulate processing delay
        setTimeout(() => {
            const modalTitle = document.getElementById('modal-title').textContent;
            
            if (modalTitle.includes('Subject')) {
                this.handleSubjectSubmit(formData);
            } else if (modalTitle.includes('Teacher')) {
                this.handleTeacherSubmit(formData);
            } else if (modalTitle.includes('Class')) {
                this.handleClassSubmit(formData);
            } else if (modalTitle.includes('Room')) {
                this.handleRoomSubmit(formData);
            }

            // Remove loading state
            if (submitButton) {
                submitButton.classList.remove('btn--loading');
                submitButton.disabled = false;
            }

            this.hideModal();
            this.updateUI();
        }, 1000);
    }

    handleSubjectSubmit(formData) {
        const subject = {
            name: formData.get('subjectName'),
            code: formData.get('subjectCode'),
            category: formData.get('category'),
            creditHours: parseInt(formData.get('creditHours')),
            description: formData.get('description') || ''
        };

        // Check for duplicate code
        if (this.data.subjects.some(s => s.code === subject.code)) {
            this.showNotification('Subject code already exists!', 'error');
            return;
        }

        this.data.subjects.push(subject);
        this.showNotification(`Subject "${subject.name}" added successfully!`, 'success');
    }

    handleTeacherSubmit(formData) {
        const subjectsTeaching = Array.from(document.querySelectorAll('input[name="subjectsTeaching"]:checked')).map(cb => cb.value);
        
        if (subjectsTeaching.length === 0) {
            this.showNotification('Please select at least one subject for the teacher.', 'error');
            return;
        }

        const teacher = {
            fullName: formData.get('fullName'),
            employeeId: formData.get('employeeId'),
            email: formData.get('email'),
            maxHoursPerWeek: parseInt(formData.get('maxHoursPerWeek')),
            subjectsTeaching: subjectsTeaching
        };

        // Check for duplicate employee ID
        if (this.data.teachers.some(t => t.employeeId === teacher.employeeId)) {
            this.showNotification('Employee ID already exists!', 'error');
            return;
        }

        this.data.teachers.push(teacher);
        this.showNotification(`Teacher "${teacher.fullName}" added successfully!`, 'success');
    }

    handleClassSubmit(formData) {
        const classTeacherIndex = formData.get('classTeacher');
        const classData = {
            className: formData.get('className'),
            gradeLevel: formData.get('gradeLevel'),
            classTeacher: classTeacherIndex ? this.data.teachers[parseInt(classTeacherIndex)] : null,
            studentCount: parseInt(formData.get('studentCount'))
        };

        // Check for duplicate class name
        if (this.data.classes.some(c => c.className === classData.className)) {
            this.showNotification('Class name already exists!', 'error');
            return;
        }

        this.data.classes.push(classData);
        this.showNotification(`Class "${classData.className}" added successfully!`, 'success');
    }

    handleRoomSubmit(formData) {
        const equipment = Array.from(document.querySelectorAll('input[name="equipment"]:checked')).map(cb => cb.value);
        
        const room = {
            roomName: formData.get('roomName'),
            roomType: formData.get('roomType'),
            capacity: parseInt(formData.get('capacity')),
            equipment: equipment
        };

        // Check for duplicate room name
        if (this.data.rooms.some(r => r.roomName === room.roomName)) {
            this.showNotification('Room name already exists!', 'error');
            return;
        }

        this.data.rooms.push(room);
        this.showNotification(`Room "${room.roomName}" added successfully!`, 'success');
    }

    // Edit functions
    editSubject(index) {
        const subject = this.data.subjects[index];
        if (!subject) return;

        this.showModal('Edit Subject', this.getSubjectFormHTML(), 'Update');
        
        // Pre-fill form
        setTimeout(() => {
            document.getElementById('subject-name').value = subject.name;
            document.getElementById('subject-code').value = subject.code;
            document.getElementById('subject-category').value = subject.category;
            document.getElementById('credit-hours').value = subject.creditHours;
            document.getElementById('subject-description').value = subject.description;
            
            // Store index for update
            document.getElementById('modal-form').setAttribute('data-edit-index', index);
        }, 100);
    }

    editTeacher(index) {
        const teacher = this.data.teachers[index];
        if (!teacher) return;

        this.showModal('Edit Teacher', this.getTeacherFormHTML(), 'Update');
        
        // Pre-fill form
        setTimeout(() => {
            document.getElementById('teacher-name').value = teacher.fullName;
            document.getElementById('employee-id').value = teacher.employeeId;
            document.getElementById('teacher-email').value = teacher.email;
            document.getElementById('max-hours').value = teacher.maxHoursPerWeek;
            
            // Select subjects
            teacher.subjectsTeaching.forEach(subject => {
                const checkbox = document.querySelector(`input[name="subjectsTeaching"][value="${subject}"]`);
                if (checkbox) checkbox.checked = true;
            });
            
            document.getElementById('modal-form').setAttribute('data-edit-index', index);
        }, 100);
    }

    editClass(index) {
        const cls = this.data.classes[index];
        if (!cls) return;

        this.showModal('Edit Class', this.getClassFormHTML(), 'Update');
        
        // Pre-fill form
        setTimeout(() => {
            document.getElementById('class-name').value = cls.className;
            document.getElementById('grade-level').value = cls.gradeLevel;
            document.getElementById('student-count').value = cls.studentCount;
            
            if (cls.classTeacher) {
                const teacherIndex = this.data.teachers.indexOf(cls.classTeacher);
                if (teacherIndex !== -1) {
                    document.getElementById('class-teacher').value = teacherIndex;
                }
            }
            
            document.getElementById('modal-form').setAttribute('data-edit-index', index);
        }, 100);
    }

    editRoom(index) {
        const room = this.data.rooms[index];
        if (!room) return;

        this.showModal('Edit Room', this.getRoomFormHTML(), 'Update');
        
        // Pre-fill form
        setTimeout(() => {
            document.getElementById('room-name').value = room.roomName;
            document.getElementById('room-type').value = room.roomType;
            document.getElementById('room-capacity').value = room.capacity;
            
            // Select equipment
            room.equipment.forEach(equip => {
                const checkbox = document.querySelector(`input[name="equipment"][value="${equip}"]`);
                if (checkbox) checkbox.checked = true;
            });
            
            document.getElementById('modal-form').setAttribute('data-edit-index', index);
        }, 100);
    }

    // Delete functions
    deleteSubject(index) {
        if (confirm('Are you sure you want to delete this subject?')) {
            this.data.subjects.splice(index, 1);
            this.updateUI();
            this.showNotification('Subject deleted successfully!', 'success');
        }
    }

    deleteTeacher(index) {
        if (confirm('Are you sure you want to delete this teacher?')) {
            this.data.teachers.splice(index, 1);
            this.updateUI();
            this.showNotification('Teacher deleted successfully!', 'success');
        }
    }

    deleteClass(index) {
        if (confirm('Are you sure you want to delete this class?')) {
            this.data.classes.splice(index, 1);
            this.updateUI();
            this.showNotification('Class deleted successfully!', 'success');
        }
    }

    deleteRoom(index) {
        if (confirm('Are you sure you want to delete this room?')) {
            this.data.rooms.splice(index, 1);
            this.updateUI();
            this.showNotification('Room deleted successfully!', 'success');
        }
    }

    // Generation and export functions
    generateTimetable() {
        const button = document.getElementById('generate-timetable-btn');
        if (button) {
            button.classList.add('btn--loading');
            button.disabled = true;
        }

        // Simulate timetable generation
        setTimeout(() => {
            this.data.timetable = {
                generatedAt: new Date(),
                conflicts: 0,
                totalSlots: this.data.generalSettings.periodsPerDay * this.data.generalSettings.workingDays.length,
                filledSlots: Math.floor(Math.random() * 80) + 70
            };

            // Show preview
            const preview = document.getElementById('timetable-preview');
            if (preview) {
                preview.classList.remove('hidden');
                this.updateTimetablePreview();
            }

            if (button) {
                button.classList.remove('btn--loading');
                button.disabled = false;
            }

            this.showNotification('Timetable generated successfully!', 'success');
        }, 3000);
    }

    updateTimetablePreview() {
        const previewGrid = document.getElementById('preview-grid');
        if (!previewGrid) return;

        previewGrid.innerHTML = `
            <div class="preview-card">
                <h4>Schedule Overview</h4>
                <p><strong>Total Periods:</strong> ${this.data.timetable.totalSlots}</p>
                <p><strong>Filled Periods:</strong> ${this.data.timetable.filledSlots}</p>
                <p><strong>Conflicts:</strong> ${this.data.timetable.conflicts}</p>
            </div>
            <div class="preview-card">
                <h4>Utilization</h4>
                <p><strong>Teachers:</strong> ${this.data.teachers.length} assigned</p>
                <p><strong>Classes:</strong> ${this.data.classes.length} scheduled</p>
                <p><strong>Rooms:</strong> ${this.data.rooms.length} available</p>
            </div>
        `;
    }

    exportToPDF() {
        this.showNotification('Exporting to PDF... (This would generate a PDF in a real application)', 'info');
    }

    exportToExcel() {
        this.showNotification('Exporting to Excel... (This would generate an Excel file in a real application)', 'info');
    }

    saveProject() {
        const projectData = {
            ...this.data,
            stepCompletion: this.stepCompletion,
            currentStep: this.currentStep,
            savedAt: new Date()
        };

        // In a real application, this would save to a server
        this.showNotification('Project saved successfully!', 'success');
        this.showSuccessModal('Your timetable project has been saved successfully! All your data and configurations are preserved.');
    }

    showSuccessModal(message) {
        const modal = document.getElementById('success-modal');
        const messageElement = document.getElementById('success-message');
        
        if (messageElement) {
            messageElement.textContent = message;
        }
        
        if (modal) {
            modal.classList.remove('hidden');
            document.body.style.overflow = 'hidden';
        }
    }

    hideSuccessModal() {
        const modal = document.getElementById('success-modal');
        if (modal) {
            modal.classList.add('hidden');
            document.body.style.overflow = '';
        }
    }

    showNotification(message, type = 'info') {
        // Create notification element
        const notification = document.createElement('div');
        notification.className = `notification notification--${type}`;
        notification.innerHTML = `
            <div class="notification-content">
                <span>${this.escapeHtml(message)}</span>
                <button class="notification-close" onclick="this.parentElement.parentElement.remove()">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <line x1="18" x2="6" y1="6" y2="18"/>
                        <line x1="6" x2="18" y1="6" y2="18"/>
                    </svg>
                </button>
            </div>
        `;

        // Add notification styles if not exist
        if (!document.querySelector('#notification-styles')) {
            const styles = document.createElement('style');
            styles.id = 'notification-styles';
            styles.textContent = `
                .notification {
                    position: fixed;
                    top: 20px;
                    right: 20px;
                    z-index: 1001;
                    max-width: 400px;
                    padding: var(--space-12) var(--space-16);
                    border-radius: var(--radius-base);
                    box-shadow: var(--shadow-lg);
                    animation: slideInRight 0.3s ease-out;
                }
                .notification--success {
                    background-color: rgba(var(--color-success-rgb), 0.1);
                    border: 1px solid var(--color-success);
                    color: var(--color-success);
                }
                .notification--error {
                    background-color: rgba(var(--color-error-rgb), 0.1);
                    border: 1px solid var(--color-error);
                    color: var(--color-error);
                }
                .notification--warning {
                    background-color: rgba(var(--color-warning-rgb), 0.1);
                    border: 1px solid var(--color-warning);
                    color: var(--color-warning);
                }
                .notification--info {
                    background-color: var(--color-bg-1);
                    border: 1px solid var(--color-border);
                    color: var(--color-text);
                }
                .notification-content {
                    display: flex;
                    align-items: center;
                    justify-content: space-between;
                    gap: var(--space-12);
                }
                .notification-close {
                    background: none;
                    border: none;
                    color: currentColor;
                    cursor: pointer;
                    padding: var(--space-4);
                    border-radius: var(--radius-sm);
                    opacity: 0.7;
                }
                .notification-close:hover { opacity: 1; }
                @keyframes slideInRight {
                    from { transform: translateX(100%); opacity: 0; }
                    to { transform: translateX(0); opacity: 1; }
                }
                @media (max-width: 480px) {
                    .notification { top: 10px; right: 10px; left: 10px; max-width: none; }
                }
            `;
            document.head.appendChild(styles);
        }

        // Add to DOM
        document.body.appendChild(notification);

        // Auto remove after 5 seconds
        setTimeout(() => {
            notification.remove();
        }, 5000);
    }

    handleResponsiveLayout() {
        // Handle responsive behavior
        const stepTabs = document.querySelector('.step-tabs');
        if (stepTabs && window.innerWidth <= 768) {
            stepTabs.scrollLeft = 0; // Reset scroll position
        }
    }

    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text || '';
        return div.innerHTML;
    }
}

// Initialize the application
document.addEventListener('DOMContentLoaded', () => {
    window.app = new TimetableWizard();
});

// Export for global access
window.TimetableWizard = TimetableWizard;